﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

CREATE TABLE [Cliente] (
    [Id] int NOT NULL IDENTITY,
    [FechaNacimiento] date NOT NULL,
    [Estado] bit NOT NULL,
    [Rut] nvarchar(50) NOT NULL,
    [NombreCompleto] nvarchar(200) NOT NULL,
    [Email] nvarchar(500) NOT NULL,
    CONSTRAINT [PK_Cliente] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [Receta] (
    [Id] int NOT NULL IDENTITY,
    [Nombre] nvarchar(100) NOT NULL,
    [Detalle] nvarchar(max) NOT NULL,
    [Estado] bit NOT NULL,
    CONSTRAINT [PK_Receta] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [TipoTorta] (
    [Id] int NOT NULL IDENTITY,
    [Nombre] nvarchar(100) NOT NULL,
    [Estado] bit NOT NULL,
    CONSTRAINT [PK_TipoTorta] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [UnidadMedida] (
    [Id] int NOT NULL IDENTITY,
    [Codigo] nvarchar(10) NOT NULL,
    [Descripcion] nvarchar(100) NOT NULL,
    [Estado] bit NOT NULL,
    CONSTRAINT [PK_UnidadMedida] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [Vendedor] (
    [Id] int NOT NULL IDENTITY,
    [CodigoTrabajador] nvarchar(100) NOT NULL,
    [Horario] nvarchar(500) NOT NULL,
    [Estado] bit NOT NULL,
    [Rut] nvarchar(50) NOT NULL,
    [NombreCompleto] nvarchar(200) NOT NULL,
    [Email] nvarchar(500) NOT NULL,
    CONSTRAINT [PK_Vendedor] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [Producto] (
    [Id] int NOT NULL IDENTITY,
    [TipoTortaId] int NOT NULL,
    [Nombre] nvarchar(150) NOT NULL,
    [Cantidad] int NOT NULL,
    [Precio] decimal(11,2) NOT NULL,
    [Relleno] nvarchar(150) NOT NULL,
    [Tamanio] float(11) NOT NULL,
    [Estado] bit NOT NULL,
    CONSTRAINT [PK_Producto] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_Producto_TipoTorta_TipoTortaId] FOREIGN KEY ([TipoTortaId]) REFERENCES [TipoTorta] ([Id]) ON DELETE CASCADE
);
GO

CREATE TABLE [MateriaPrima] (
    [Id] int NOT NULL IDENTITY,
    [Nombre] nvarchar(100) NOT NULL,
    [Cantidad] decimal(11,2) NOT NULL,
    [UnidadMedidaId] int NOT NULL,
    [Caducidad] date NOT NULL,
    [Estado] bit NOT NULL,
    CONSTRAINT [PK_MateriaPrima] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_MateriaPrima_UnidadMedida_UnidadMedidaId] FOREIGN KEY ([UnidadMedidaId]) REFERENCES [UnidadMedida] ([Id]) ON DELETE CASCADE
);
GO

CREATE TABLE [Pedido] (
    [Id] int NOT NULL IDENTITY,
    [Fecha] date NOT NULL,
    [ClienteId] int NOT NULL,
    [VendedorId] int NULL,
    [EstadoPedido] int NOT NULL,
    [TipoPedido] int NOT NULL,
    [TotalVenta] decimal(11,2) NOT NULL,
    [UrlImagen] varchar(1000) NULL,
    [FechaRetiro] date NULL,
    [Estado] bit NOT NULL,
    CONSTRAINT [PK_Pedido] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_Pedido_Cliente_ClienteId] FOREIGN KEY ([ClienteId]) REFERENCES [Cliente] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_Pedido_Vendedor_VendedorId] FOREIGN KEY ([VendedorId]) REFERENCES [Vendedor] ([Id])
);
GO

CREATE TABLE [PedidoItem] (
    [Id] int NOT NULL IDENTITY,
    [PedidoId] int NOT NULL,
    [ProductoId] int NOT NULL,
    [TipoTortaId] int NOT NULL,
    [Tamanio] float(11) NOT NULL,
    [Relleno] nvarchar(150) NOT NULL,
    [PrecioUnitario] decimal(11,2) NOT NULL,
    [Cantidad] decimal(11,2) NOT NULL,
    [Estado] bit NOT NULL,
    CONSTRAINT [PK_PedidoItem] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_PedidoItem_Pedido_PedidoId] FOREIGN KEY ([PedidoId]) REFERENCES [Pedido] ([Id]) ON DELETE NO ACTION,
    CONSTRAINT [FK_PedidoItem_Producto_ProductoId] FOREIGN KEY ([ProductoId]) REFERENCES [Producto] ([Id]) ON DELETE NO ACTION,
    CONSTRAINT [FK_PedidoItem_TipoTorta_TipoTortaId] FOREIGN KEY ([TipoTortaId]) REFERENCES [TipoTorta] ([Id]) ON DELETE NO ACTION
);
GO

IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Codigo', N'Descripcion', N'Estado') AND [object_id] = OBJECT_ID(N'[UnidadMedida]'))
    SET IDENTITY_INSERT [UnidadMedida] ON;
INSERT INTO [UnidadMedida] ([Id], [Codigo], [Descripcion], [Estado])
VALUES (1, N'Und.', N'Unidades', CAST(1 AS bit)),
(2, N'Gr.', N'Gramos', CAST(1 AS bit)),
(3, N'Kg.', N'Kilos', CAST(1 AS bit)),
(4, N'Bot.', N'Botella', CAST(1 AS bit)),
(5, N'Fra.', N'Frasco', CAST(1 AS bit)),
(6, N'Bol', N'Bolsa', CAST(1 AS bit));
IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Codigo', N'Descripcion', N'Estado') AND [object_id] = OBJECT_ID(N'[UnidadMedida]'))
    SET IDENTITY_INSERT [UnidadMedida] OFF;
GO

CREATE INDEX [IX_MateriaPrima_UnidadMedidaId] ON [MateriaPrima] ([UnidadMedidaId]);
GO

CREATE INDEX [IX_Pedido_ClienteId] ON [Pedido] ([ClienteId]);
GO

CREATE INDEX [IX_Pedido_VendedorId] ON [Pedido] ([VendedorId]);
GO

CREATE INDEX [IX_PedidoItem_PedidoId] ON [PedidoItem] ([PedidoId]);
GO

CREATE INDEX [IX_PedidoItem_ProductoId] ON [PedidoItem] ([ProductoId]);
GO

CREATE INDEX [IX_PedidoItem_TipoTortaId] ON [PedidoItem] ([TipoTortaId]);
GO

CREATE INDEX [IX_Producto_TipoTortaId] ON [Producto] ([TipoTortaId]);
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230704172442_v1.0.0', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [Producto] ADD [ImagenUrl] varchar(1000) NULL;
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230705064727_v2.0.0', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [Vendedor] ADD [Direccion] nvarchar(500) NULL;
GO

ALTER TABLE [Cliente] ADD [Direccion] nvarchar(500) NULL;
GO

CREATE TABLE [Rol] (
    [Id] nvarchar(450) NOT NULL,
    [Name] nvarchar(256) NULL,
    [NormalizedName] nvarchar(256) NULL,
    [ConcurrencyStamp] nvarchar(max) NULL,
    CONSTRAINT [PK_Rol] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [Usuario] (
    [Id] nvarchar(450) NOT NULL,
    [Rut] nvarchar(50) NOT NULL,
    [NombreCompleto] nvarchar(200) NOT NULL,
    [FechaNacimiento] date NOT NULL,
    [Direccion] nvarchar(500) NULL,
    [UserName] nvarchar(256) NULL,
    [NormalizedUserName] nvarchar(256) NULL,
    [Email] nvarchar(256) NULL,
    [NormalizedEmail] nvarchar(256) NULL,
    [EmailConfirmed] bit NOT NULL,
    [PasswordHash] nvarchar(max) NULL,
    [SecurityStamp] nvarchar(max) NULL,
    [ConcurrencyStamp] nvarchar(max) NULL,
    [PhoneNumber] nvarchar(max) NULL,
    [PhoneNumberConfirmed] bit NOT NULL,
    [TwoFactorEnabled] bit NOT NULL,
    [LockoutEnd] datetimeoffset NULL,
    [LockoutEnabled] bit NOT NULL,
    [AccessFailedCount] int NOT NULL,
    CONSTRAINT [PK_Usuario] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [AspNetRoleClaims] (
    [Id] int NOT NULL IDENTITY,
    [RoleId] nvarchar(450) NOT NULL,
    [ClaimType] nvarchar(max) NULL,
    [ClaimValue] nvarchar(max) NULL,
    CONSTRAINT [PK_AspNetRoleClaims] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_AspNetRoleClaims_Rol_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [Rol] ([Id]) ON DELETE CASCADE
);
GO

CREATE TABLE [AspNetUserClaims] (
    [Id] int NOT NULL IDENTITY,
    [UserId] nvarchar(450) NOT NULL,
    [ClaimType] nvarchar(max) NULL,
    [ClaimValue] nvarchar(max) NULL,
    CONSTRAINT [PK_AspNetUserClaims] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_AspNetUserClaims_Usuario_UserId] FOREIGN KEY ([UserId]) REFERENCES [Usuario] ([Id]) ON DELETE CASCADE
);
GO

CREATE TABLE [AspNetUserLogins] (
    [LoginProvider] nvarchar(450) NOT NULL,
    [ProviderKey] nvarchar(450) NOT NULL,
    [ProviderDisplayName] nvarchar(max) NULL,
    [UserId] nvarchar(450) NOT NULL,
    CONSTRAINT [PK_AspNetUserLogins] PRIMARY KEY ([LoginProvider], [ProviderKey]),
    CONSTRAINT [FK_AspNetUserLogins_Usuario_UserId] FOREIGN KEY ([UserId]) REFERENCES [Usuario] ([Id]) ON DELETE CASCADE
);
GO

CREATE TABLE [AspNetUserTokens] (
    [UserId] nvarchar(450) NOT NULL,
    [LoginProvider] nvarchar(450) NOT NULL,
    [Name] nvarchar(450) NOT NULL,
    [Value] nvarchar(max) NULL,
    CONSTRAINT [PK_AspNetUserTokens] PRIMARY KEY ([UserId], [LoginProvider], [Name]),
    CONSTRAINT [FK_AspNetUserTokens_Usuario_UserId] FOREIGN KEY ([UserId]) REFERENCES [Usuario] ([Id]) ON DELETE CASCADE
);
GO

CREATE TABLE [UsuarioRol] (
    [UserId] nvarchar(450) NOT NULL,
    [RoleId] nvarchar(450) NOT NULL,
    CONSTRAINT [PK_UsuarioRol] PRIMARY KEY ([UserId], [RoleId]),
    CONSTRAINT [FK_UsuarioRol_Rol_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [Rol] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_UsuarioRol_Usuario_UserId] FOREIGN KEY ([UserId]) REFERENCES [Usuario] ([Id]) ON DELETE CASCADE
);
GO

CREATE INDEX [IX_AspNetRoleClaims_RoleId] ON [AspNetRoleClaims] ([RoleId]);
GO

CREATE INDEX [IX_AspNetUserClaims_UserId] ON [AspNetUserClaims] ([UserId]);
GO

CREATE INDEX [IX_AspNetUserLogins_UserId] ON [AspNetUserLogins] ([UserId]);
GO

CREATE UNIQUE INDEX [RoleNameIndex] ON [Rol] ([NormalizedName]) WHERE [NormalizedName] IS NOT NULL;
GO

CREATE INDEX [EmailIndex] ON [Usuario] ([NormalizedEmail]);
GO

CREATE UNIQUE INDEX [UserNameIndex] ON [Usuario] ([NormalizedUserName]) WHERE [NormalizedUserName] IS NOT NULL;
GO

CREATE INDEX [IX_UsuarioRol_RoleId] ON [UsuarioRol] ([RoleId]);
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230705181253_v3.0.0', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [PedidoItem] ADD [Total] decimal(11,2) NOT NULL DEFAULT 0.0;
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230705214847_v3.0.1', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [Producto] ADD [Especial] bit NOT NULL DEFAULT CAST(0 AS bit);
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230709002459_v3.1.0', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [Pedido] ADD [MensajePersonalizado] nvarchar(500) NULL;
GO

ALTER TABLE [Pedido] ADD [NroPedido] nvarchar(30) NULL;
GO

CREATE PROCEDURE uspListarPedidos(@FechaInicio DATE, @FechaFin DATE, @Filter NVARCHAR(100) = NULL) AS
BEGIN
	SELECT
		p.Id,
		p.Fecha ,
		p.UrlImagen ,
		item.Tamanio,
		item.Relleno,
		item.TipoTorta,
		item.Precio,
		item.Cantidad ,
		c.Id ClienteId,
		c.NombreCompleto Cliente,
		c.Direccion ,
		c.Rut ,
		v.Id VendedorId,
		v.NombreCompleto Vendedor,
		p.TotalVenta,
		p.FechaRetiro ,
		p.NroPedido,
		p.MensajePersonalizado,
		p.EstadoPedido,
		'Pedido Especial' Origen
	FROM
		Pedido p
	CROSS APPLY (
		SELECT
			TOP 1 i.ProductoId ,
			i.Tamanio,
			i.Relleno,
			i.Cantidad,
			tt.Nombre TipoTorta,
			prod.Precio
		FROM
			PedidoItem i
		INNER JOIN Producto prod ON
			i.ProductoId = prod.Id
		INNER JOIN TipoTorta tt ON
			i.TipoTortaId = tt.Id
		WHERE
			p.Id = i.PedidoId) Item
	LEFT JOIN Cliente c ON
		c.Id = p.ClienteId
	LEFT JOIN Vendedor v ON
		v.Id = p.VendedorId
	WHERE p.TipoPedido = 1
	AND p.Fecha BETWEEN @FechaInicio AND @FechaFin
	AND (@Filter IS NULL OR (C.Rut LIKE @Filter + '%' OR C.NombreCompleto LIKE '%' + @Filter + '%'))
	UNION ALL
	SELECT 
		p.Id,
		p.Fecha ,
		p.UrlImagen ,
		item.Tamanio,
		item.Relleno,
		tt.Nombre TipoTorta ,
		item.PrecioUnitario Precio,
		item.Cantidad ,
		c.Id ClienteId,
		c.NombreCompleto Cliente,
		c.Direccion ,
		c.Rut ,
		v.Id VendedorId,
		v.NombreCompleto Vendedor,
		p.TotalVenta,
		p.FechaRetiro ,
		p.NroPedido,
		p.MensajePersonalizado,
		p.EstadoPedido,
		'Carrito' Origen
	FROM
		Pedido p
	INNER JOIN PedidoItem item ON
		P.Id = item.PedidoId
	INNER JOIN TipoTorta tt ON
		TT.Id = item.TipoTortaId
	LEFT JOIN Cliente c ON
		c.Id = p.ClienteId
	LEFT JOIN Vendedor v ON
		v.Id = p.VendedorId
	WHERE p.TipoPedido = 0
	AND p.Fecha BETWEEN @FechaInicio AND @FechaFin
	AND (@Filter IS NULL OR (C.Rut LIKE @Filter + '%' OR C.NombreCompleto LIKE '%' + @Filter + '%'))
	ORDER BY Fecha DESC
END
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230710172359_v4.0.0', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [Vendedor] ADD [PeriodEnd] datetime2 NOT NULL DEFAULT '9999-12-31T23:59:59.9999999';
GO

ALTER TABLE [Vendedor] ADD [PeriodStart] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
GO

ALTER TABLE [Producto] ADD [PeriodEnd] datetime2 NOT NULL DEFAULT '9999-12-31T23:59:59.9999999';
GO

ALTER TABLE [Producto] ADD [PeriodStart] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
GO

ALTER TABLE [Pedido] ADD [PeriodEnd] datetime2 NOT NULL DEFAULT '9999-12-31T23:59:59.9999999';
GO

ALTER TABLE [Pedido] ADD [PeriodStart] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
GO

ALTER TABLE [MateriaPrima] ADD [PeriodEnd] datetime2 NOT NULL DEFAULT '9999-12-31T23:59:59.9999999';
GO

ALTER TABLE [MateriaPrima] ADD [PeriodStart] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
GO

ALTER TABLE [Cliente] ADD [PeriodEnd] datetime2 NOT NULL DEFAULT '9999-12-31T23:59:59.9999999';
GO

ALTER TABLE [Cliente] ADD [PeriodStart] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
GO

ALTER TABLE [Vendedor] ADD PERIOD FOR SYSTEM_TIME ([PeriodStart], [PeriodEnd])
GO

ALTER TABLE [Vendedor] ALTER COLUMN [PeriodStart] ADD HIDDEN
GO

ALTER TABLE [Vendedor] ALTER COLUMN [PeriodEnd] ADD HIDDEN
GO

ALTER TABLE [Producto] ADD PERIOD FOR SYSTEM_TIME ([PeriodStart], [PeriodEnd])
GO

ALTER TABLE [Producto] ALTER COLUMN [PeriodStart] ADD HIDDEN
GO

ALTER TABLE [Producto] ALTER COLUMN [PeriodEnd] ADD HIDDEN
GO

ALTER TABLE [Pedido] ADD PERIOD FOR SYSTEM_TIME ([PeriodStart], [PeriodEnd])
GO

ALTER TABLE [Pedido] ALTER COLUMN [PeriodStart] ADD HIDDEN
GO

ALTER TABLE [Pedido] ALTER COLUMN [PeriodEnd] ADD HIDDEN
GO

ALTER TABLE [MateriaPrima] ADD PERIOD FOR SYSTEM_TIME ([PeriodStart], [PeriodEnd])
GO

ALTER TABLE [MateriaPrima] ALTER COLUMN [PeriodStart] ADD HIDDEN
GO

ALTER TABLE [MateriaPrima] ALTER COLUMN [PeriodEnd] ADD HIDDEN
GO

ALTER TABLE [Cliente] ADD PERIOD FOR SYSTEM_TIME ([PeriodStart], [PeriodEnd])
GO

ALTER TABLE [Cliente] ALTER COLUMN [PeriodStart] ADD HIDDEN
GO

ALTER TABLE [Cliente] ALTER COLUMN [PeriodEnd] ADD HIDDEN
GO

DECLARE @historyTableSchema sysname = SCHEMA_NAME()
EXEC(N'ALTER TABLE [Vendedor] SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [' + @historyTableSchema + '].[VendedorHistory]))')

GO

DECLARE @historyTableSchema sysname = SCHEMA_NAME()
EXEC(N'ALTER TABLE [Producto] SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [' + @historyTableSchema + '].[ProductoHistory]))')

GO

DECLARE @historyTableSchema sysname = SCHEMA_NAME()
EXEC(N'ALTER TABLE [Pedido] SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [' + @historyTableSchema + '].[PedidoHistory]))')

GO

DECLARE @historyTableSchema sysname = SCHEMA_NAME()
EXEC(N'ALTER TABLE [MateriaPrima] SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [' + @historyTableSchema + '].[MateriaPrimaHistory]))')

GO

DECLARE @historyTableSchema sysname = SCHEMA_NAME()
EXEC(N'ALTER TABLE [Cliente] SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [' + @historyTableSchema + '].[ClienteHistory]))')

GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230711121950_v5.0.0', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [Vendedor] ADD [Usuario] nvarchar(max) NULL;
GO

ALTER TABLE [UnidadMedida] ADD [Usuario] nvarchar(max) NULL;
GO

ALTER TABLE [TipoTorta] ADD [Usuario] nvarchar(max) NULL;
GO

ALTER TABLE [Receta] ADD [Usuario] nvarchar(max) NULL;
GO

ALTER TABLE [Producto] ADD [Usuario] nvarchar(max) NULL;
GO

ALTER TABLE [PedidoItem] ADD [Usuario] nvarchar(max) NULL;
GO

ALTER TABLE [Pedido] ADD [Usuario] nvarchar(max) NULL;
GO

ALTER TABLE [MateriaPrima] ADD [Usuario] nvarchar(max) NULL;
GO

ALTER TABLE [Cliente] ADD [Usuario] nvarchar(max) NULL;
GO

UPDATE [UnidadMedida] SET [Usuario] = NULL
WHERE [Id] = 1;
SELECT @@ROWCOUNT;

GO

UPDATE [UnidadMedida] SET [Usuario] = NULL
WHERE [Id] = 2;
SELECT @@ROWCOUNT;

GO

UPDATE [UnidadMedida] SET [Usuario] = NULL
WHERE [Id] = 3;
SELECT @@ROWCOUNT;

GO

UPDATE [UnidadMedida] SET [Usuario] = NULL
WHERE [Id] = 4;
SELECT @@ROWCOUNT;

GO

UPDATE [UnidadMedida] SET [Usuario] = NULL
WHERE [Id] = 5;
SELECT @@ROWCOUNT;

GO

UPDATE [UnidadMedida] SET [Usuario] = NULL
WHERE [Id] = 6;
SELECT @@ROWCOUNT;

GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230713220016_v5.1.0', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

CREATE PROC uspAuditoriaPedidos
AS
BEGIN
	-- PEDIDOS
SELECT
	TOP 100 [p].[Id],
	[p].[NroPedido],
	[p].[Fecha],
	[c].[NombreCompleto] AS [Cliente],
	CASE
		[p].[EstadoPedido] 
WHEN 0 THEN 'Pendiente'
		WHEN 1 THEN 'En Preparación'
		WHEN 2 THEN 'En Camino'
		WHEN 3 THEN 'Entregado'
	END AS EstadoPedido
,
	[v].[NombreCompleto] AS [Vendedor],
	P.Usuario
,
	[p].[PeriodEnd] AS [FechaCambio]
FROM
	[PedidoHistory] AS [p]
INNER JOIN [Cliente] AS [c] ON
	[p].[ClienteId] = [c].[Id]
LEFT JOIN [Vendedor] AS [v] ON
	[p].[VendedorId] = [v].[Id]
ORDER BY
	P.Id DESC,
	P.PeriodEnd DESC
END
GO

CREATE PROCEDURE uspAuditoriaProductos
AS 
BEGIN
-- PRODUCTOS
SELECT
	TOP 50
	P.Id,
	P.Nombre,
	P.Cantidad,
	P.Precio,
	P.Relleno,
	TT.Nombre TipoTorta,
	P.Tamanio,
	CASE
		P.Estado 
	WHEN 1 THEN 'Activo'
		WHEN 0 THEN 'Borrado'
	END Estado,
	P.Usuario,
	P.PeriodEnd FechaCambio
FROM
	ProductoHistory P
LEFT JOIN TipoTorta TT ON
	TT.Id = P.TipoTortaId
ORDER BY
	P.ID DESC,
	P.PeriodEnd DESC
END
GO

CREATE PROCEDURE uspAuditoriaMateriaPrimas
AS 
BEGIN
-- MATERIAS PRIMA
SELECT
	TOP 50
	MP.Id,
	MP.Nombre,
	MP.Caducidad,
	MP.Cantidad,
	UM.Descripcion UnidadMedida,
	CASE
		MP.Estado 
	WHEN 1 THEN 'Activo'
		WHEN 0 THEN 'Borrado'
	END Estado,
	MP.PeriodEnd AS FechaCambio,
	MP.Usuario
FROM
	MateriaPrimaHistory MP
INNER JOIN UnidadMedida UM ON
	UM.Id = MP.Id
ORDER BY
	MP.ID DESC,
	MP.PeriodEnd DESC
END
GO

CREATE PROCEDURE uspAuditoriaClientes
AS 
BEGIN
--CLIENTES
SELECT
	TOP 50
	C.ID,
	C.NombreCompleto,
	C.Rut,
	C.Email,
	C.Direccion,
	C.FechaNacimiento,
	CASE
		C.Estado 
	WHEN 1 THEN 'Activo'
		WHEN 0 THEN 'Borrado'
	END Estado,
	C.Usuario,
	C.PeriodEnd FechaCambio
FROM
	ClienteHistory C
ORDER BY
	C.ID DESC,
	C.PeriodEnd DESC
END 
GO

CREATE PROCEDURE uspAuditoriaVendedores
AS
BEGIN
--VENDEDOR
SELECT
	TOP 50
	V.ID,
	V.NombreCompleto,
	V.Rut,
	V.Email,
	V.Direccion,
	V.Horario,
	CASE
		V.Estado 
	WHEN 1 THEN 'Activo'
		WHEN 0 THEN 'Borrado'
	END Estado,
	V.Usuario,
	V.PeriodEnd FechaCambio
FROM
	VendedorHistory V
ORDER BY
	V.ID DESC,
	V.PeriodEnd DESC
END 
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230713221958_v5.2.0', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

CREATE OR ALTER PROC uspAuditoriaPedidos
AS
BEGIN
	-- PEDIDOS
SELECT
	TOP 100 [p].[Id],
	[p].[NroPedido],
	[p].[Fecha],
	[c].[NombreCompleto] AS [Cliente],
	CASE
		[p].[EstadoPedido] 
WHEN 0 THEN 'Pendiente'
		WHEN 1 THEN 'En Preparación'
		WHEN 2 THEN 'En Camino'
		WHEN 3 THEN 'Entregado'
	END AS EstadoPedido
,
	[v].[NombreCompleto] AS [Vendedor],
	P.Usuario
,
	[p].[PeriodEnd] AS [FechaCambio]
FROM
	[PedidoHistory] AS [p]
INNER JOIN [Cliente] AS [c] ON
	[p].[ClienteId] = [c].[Id]
LEFT JOIN [Vendedor] AS [v] ON
	[p].[VendedorId] = [v].[Id]
ORDER BY
	P.PeriodEnd DESC
END
GO

CREATE OR ALTER PROCEDURE uspAuditoriaProductos
AS 
BEGIN
-- PRODUCTOS
SELECT
	TOP 50
	P.Id,
	P.Nombre,
	P.Cantidad,
	P.Precio,
	P.Relleno,
	TT.Nombre TipoTorta,
	P.Tamanio,
	CASE
		P.Estado 
	WHEN 1 THEN 'Activo'
		WHEN 0 THEN 'Borrado'
	END Estado,
	P.Usuario,
	P.PeriodEnd FechaCambio
FROM
	ProductoHistory P
LEFT JOIN TipoTorta TT ON
	TT.Id = P.TipoTortaId
ORDER BY
	P.PeriodEnd DESC
END
GO

CREATE OR ALTER PROCEDURE uspAuditoriaMateriaPrimas
AS 
BEGIN
-- MATERIAS PRIMA
SELECT
	TOP 50
	MP.Id,
	MP.Nombre,
	MP.Caducidad,
	MP.Cantidad,
	UM.Descripcion UnidadMedida,
	CASE
		MP.Estado 
	WHEN 1 THEN 'Activo'
		WHEN 0 THEN 'Borrado'
	END Estado,
	MP.PeriodEnd AS FechaCambio,
	MP.Usuario
FROM
	MateriaPrimaHistory MP
INNER JOIN UnidadMedida UM ON
	UM.Id = MP.Id
ORDER BY
	MP.PeriodEnd DESC
END
GO

CREATE OR ALTER PROCEDURE uspAuditoriaClientes
AS 
BEGIN
--CLIENTES
SELECT
	TOP 50
	C.ID,
	C.NombreCompleto,
	C.Rut,
	C.Email,
	C.Direccion,
	C.FechaNacimiento,
	CASE
		C.Estado 
	WHEN 1 THEN 'Activo'
		WHEN 0 THEN 'Borrado'
	END Estado,
	C.Usuario,
	C.PeriodEnd FechaCambio
FROM
	ClienteHistory C
ORDER BY
	C.PeriodEnd DESC
END 
GO

CREATE OR ALTER PROCEDURE uspAuditoriaVendedores
AS
BEGIN
--VENDEDOR
SELECT
	TOP 50
	V.ID,
	V.NombreCompleto,
	V.Rut,
	V.Email,
	V.Direccion,
	V.Horario,
	CASE
		V.Estado 
	WHEN 1 THEN 'Activo'
		WHEN 0 THEN 'Borrado'
	END Estado,
	V.Usuario,
	V.PeriodEnd FechaCambio
FROM
	VendedorHistory V
ORDER BY
	V.PeriodEnd DESC
END 
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230714045846_v5.3.0', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [Pedido] ADD [JsonPayPalResponse] nvarchar(max) NULL;
GO

CREATE PROCEDURE uspReporteTipoTortaTotal 
(@FechaInicio DATE,
@FechaFin DATE)
AS
BEGIN
	SELECT 
	TT.Nombre TipoTorta ,
	SUM(P.TotalVenta) SumaTotal
FROM
	PedidoITEM ITEM
INNER JOIN TipoTorta tt ON
	ITEM.TipoTortaId = TT.Id
INNER JOIN Pedido p ON
	ITEM.PedidoId = P.Id
WHERE
	P.EstadoPedido <> 4
	AND P.Fecha BETWEEN @FechaInicio AND @FechaFin
GROUP BY
	TT.Nombre
ORDER BY
	2
END 
GO

CREATE PROCEDURE uspReporteCantidades
(@FechaInicio DATE,
@FechaFin DATE)
AS
BEGIN
	SELECT 
	(
	SELECT
		COUNT(PROD.ID)
	FROM
		Producto PROD
	WHERE
		PROD.Estado = 1) CantidadProductos,
	(
	SELECT
		COUNT(CLI.ID)
	FROM
		Cliente CLI
	WHERE
		CLI.Estado = 1) CantidadClientes,
	COUNT(P.Id) CantidadVentas,
	SUM(P.TotalVenta) SumaTotalVentas,
	AVG(P.TotalVenta) VentaPromedio
FROM
	Pedido P
WHERE
	P.EstadoPedido <> 4
	AND P.Fecha BETWEEN @FechaInicio AND @FechaFin
ORDER BY
	2
END 


GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230714165704_v6.0.0', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [Pedido] ADD [PayPalUrlOrder] nvarchar(max) NULL;
GO

CREATE OR ALTER PROCEDURE uspListarPedidos(@FechaInicio DATE, @FechaFin DATE, @Filter NVARCHAR(100) = NULL) AS
BEGIN
	SELECT
		p.Id,
		p.Fecha ,
		p.UrlImagen ,
		item.Tamanio,
		item.Relleno,
		item.TipoTorta,
		item.Precio,
		item.Cantidad ,
		c.Id ClienteId,
		c.NombreCompleto Cliente,
		c.Direccion ,
		c.Rut ,
		v.Id VendedorId,
		v.NombreCompleto Vendedor,
		p.TotalVenta,
		p.FechaRetiro ,
		p.NroPedido,
		p.MensajePersonalizado,
		p.EstadoPedido,
		p.JsonPayPalResponse ,
		p.PayPalUrlOrder,
		'Pedido Especial' Origen
	FROM
		Pedido p
	CROSS APPLY (
		SELECT
			TOP 1 i.ProductoId ,
			i.Tamanio,
			i.Relleno,
			i.Cantidad,
			tt.Nombre TipoTorta,
			prod.Precio
		FROM
			PedidoItem i
		INNER JOIN Producto prod ON
			i.ProductoId = prod.Id
		INNER JOIN TipoTorta tt ON
			i.TipoTortaId = tt.Id
		WHERE
			p.Id = i.PedidoId) Item
	LEFT JOIN Cliente c ON
		c.Id = p.ClienteId
	LEFT JOIN Vendedor v ON
		v.Id = p.VendedorId
	WHERE p.TipoPedido = 1
	AND p.Fecha BETWEEN @FechaInicio AND @FechaFin
	AND (@Filter IS NULL OR (C.Rut LIKE @Filter + '%' OR C.NombreCompleto LIKE '%' + @Filter + '%'))
	UNION ALL
	SELECT 
		p.Id,
		p.Fecha ,
		p.UrlImagen ,
		item.Tamanio,
		item.Relleno,
		tt.Nombre TipoTorta ,
		item.PrecioUnitario Precio,
		item.Cantidad ,
		c.Id ClienteId,
		c.NombreCompleto Cliente,
		c.Direccion ,
		c.Rut ,
		v.Id VendedorId,
		v.NombreCompleto Vendedor,
		p.TotalVenta,
		p.FechaRetiro ,
		p.NroPedido,
		p.MensajePersonalizado,
		p.EstadoPedido,
		p.JsonPayPalResponse ,
		p.PayPalUrlOrder,
		'Carrito' Origen
	FROM
		Pedido p
	INNER JOIN PedidoItem item ON
		P.Id = item.PedidoId
	INNER JOIN TipoTorta tt ON
		TT.Id = item.TipoTortaId
	LEFT JOIN Cliente c ON
		c.Id = p.ClienteId
	LEFT JOIN Vendedor v ON
		v.Id = p.VendedorId
	WHERE p.TipoPedido = 0
	AND p.Fecha BETWEEN @FechaInicio AND @FechaFin
	AND (@Filter IS NULL OR (C.Rut LIKE @Filter + '%' OR C.NombreCompleto LIKE '%' + @Filter + '%'))
	ORDER BY Fecha DESC
END

GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230717041759_PayPalIntegration', N'7.0.9');
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [Usuario] ADD [Latitud] nvarchar(max) NULL;
GO

ALTER TABLE [Usuario] ADD [Longitud] nvarchar(max) NULL;
GO

ALTER TABLE [Cliente] ADD [Latitud] nvarchar(max) NULL;
GO

ALTER TABLE [Cliente] ADD [Longitud] nvarchar(max) NULL;
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230718204215_UbicacionGeografica', N'7.0.9');
GO

COMMIT;
GO

